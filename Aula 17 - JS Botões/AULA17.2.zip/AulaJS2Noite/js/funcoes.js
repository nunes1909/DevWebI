function somar(){
    //Inicio da entrada de dados 
    var x = window.prompt("Informe o valor de X: ");
    var y = window.prompt("Informe o valor de Y: ");
    //Fim da entrada de dados


    //Inicio do processamento
    var soma = parseInt(x) + parseFloat(y);
    //Fim do processamento


    //Inicio da saída de dados 
    window.alert("A soma entre x e y é: "+soma);
    //Fim da saída de dados
}
function subtrair(){
    //Inicio da entrada de dados 
    var x = window.prompt("Informe o valor de X: ");
    var y = window.prompt("Informe o valor de Y: ");
    //Fim da entrada de dados


    //Inicio do processamento
    var soma = parseInt(x) - parseFloat(y);
    //Fim do processamento


    //Inicio da saída de dados 
    window.alert("A soma entre x e y é: "+soma);
    //Fim da saída de dados
}
function multiplicar(){
    //Inicio da entrada de dados 
    var x = window.prompt("Informe o valor de X: ");
    var y = window.prompt("Informe o valor de Y: ");
    //Fim da entrada de dados


    //Inicio do processamento
    var soma = parseInt(x) * parseFloat(y);
    //Fim do processamento


    //Inicio da saída de dados 
    window.alert("A soma entre x e y é: "+soma);
    //Fim da saída de dados
}
function dividir(){
    //Inicio da entrada de dados 
    var x = window.prompt("Informe o valor de X: ");
    var y = window.prompt("Informe o valor de Y: ");
    //Fim da entrada de dados


    //Inicio do processamento
    var soma = parseInt(x) / parseFloat(y);
    //Fim do processamento


    //Inicio da saída de dados 
    window.alert("A soma entre x e y é: "+soma);
    //Fim da saída de dados
}
function calcularRestoDaDivisao(){
    //Inicio da entrada de dados 
    var x = window.prompt("Informe o valor de X: ");
    var y = window.prompt("Informe o valor de Y: ");
    //Fim da entrada de dados


    //Inicio do processamento
    var soma = parseInt(x) % parseFloat(y);
    //Fim do processamento


    //Inicio da saída de dados 
    window.alert("A soma entre x e y é: "+soma);
    //Fim da saída de dados
}
function calcularPotencia(){
    //Inicio da entrada de dados 
    var x = window.prompt("Informe o valor de X: ");
    var y = window.prompt("Informe o valor de Y: ");
    //Fim da entrada de dados


    //Inicio do processamento
    var soma = parseInt(x) ** parseFloat(y);
    
    var soma = Math.pow(parseInt(x),parseFloat(y));
    //Fim do processamento


    //Inicio da saída de dados 
    window.alert("A soma entre x e y é: "+soma);
    //Fim da saída de dados
}